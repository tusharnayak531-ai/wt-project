(() => {
  const sidebar = document.getElementById('sidebar');
  document.getElementById('menuToggle')?.addEventListener('click', () => sidebar?.classList.toggle('open'));
  document.addEventListener('click', event => {
    if (sidebar?.classList.contains('open') && !sidebar.contains(event.target) && !event.target.closest('#menuToggle')) sidebar.classList.remove('open');
  });
  document.querySelectorAll('[data-open]').forEach(button => button.addEventListener('click', () => {
    const dialog = document.getElementById(button.dataset.open);
    if(dialog){ dialog.hidden = false; dialog.querySelector('input:not([type=hidden])')?.focus(); }
  }));
  const closeDialogs = () => document.querySelectorAll('.modal-backdrop').forEach(dialog => dialog.hidden = true);
  document.querySelectorAll('[data-close]').forEach(button => button.addEventListener('click', closeDialogs));
  document.querySelectorAll('.modal-backdrop').forEach(dialog => dialog.addEventListener('click', event => { if(event.target===dialog)closeDialogs(); }));
  document.addEventListener('keydown', event => { if(event.key==='Escape')closeDialogs(); });
  document.querySelectorAll('[data-search]').forEach(input => input.addEventListener('input', () => {
    const rows = document.querySelectorAll(`#${CSS.escape(input.dataset.search)} tbody tr`);
    const term = input.value.toLocaleLowerCase().trim();
    rows.forEach(row => row.hidden = !row.textContent.toLocaleLowerCase().includes(term));
  }));
})();
