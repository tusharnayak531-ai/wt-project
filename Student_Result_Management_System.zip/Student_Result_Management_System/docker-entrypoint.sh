#!/bin/sh
set -eu
PORT="${PORT:-10000}"
sed -i "s/Listen 80/Listen ${PORT}/" /etc/apache2/ports.conf
sed -i "s/<VirtualHost \*:80>/<VirtualHost *:${PORT}>/" /etc/apache2/sites-available/000-default.conf
if [ -z "${EXTERNAL_MYSQL_HOST:-}" ]; then
  mkdir -p /run/mysqld
  chown mysql:mysql /run/mysqld /var/lib/mysql
  if [ ! -d /var/lib/mysql/mysql ]; then mariadb-install-db --user=mysql --datadir=/var/lib/mysql --skip-test-db >/dev/null; fi
  mariadbd --user=mysql --datadir=/var/lib/mysql --socket=/run/mysqld/mysqld.sock --bind-address=127.0.0.1 --port=3306 &
  tries=0
  until mariadb-admin --socket=/run/mysqld/mysqld.sock ping --silent >/dev/null 2>&1; do
    tries=$((tries+1))
    if [ "$tries" -ge 50 ]; then echo 'MySQL startup failed' >&2; exit 1; fi
    sleep 1
  done
  : "${DB_PASSWORD:?Set DB_PASSWORD in Render environment variables}"
  mariadb --socket=/run/mysqld/mysqld.sock -uroot <<SQL
CREATE DATABASE IF NOT EXISTS \`${DB_NAME:-iu_result_portal}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS '${DB_USER:-resultapp}'@'localhost' IDENTIFIED BY '${DB_PASSWORD}';
CREATE USER IF NOT EXISTS '${DB_USER:-resultapp}'@'127.0.0.1' IDENTIFIED BY '${DB_PASSWORD}';
GRANT ALL PRIVILEGES ON \`${DB_NAME:-iu_result_portal}\`.* TO '${DB_USER:-resultapp}'@'localhost';
GRANT ALL PRIVILEGES ON \`${DB_NAME:-iu_result_portal}\`.* TO '${DB_USER:-resultapp}'@'127.0.0.1';
FLUSH PRIVILEGES;
SQL
else
  export DB_HOST="$EXTERNAL_MYSQL_HOST"
fi
exec apache2-foreground
