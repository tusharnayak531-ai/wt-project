# IU ResultHub — Student Result Management System

A Web Technology mini project using **HTML, CSS, JavaScript, PHP 8.3 and MySQL-compatible MariaDB**. Designed for Indus University B.Tech CSE semester 5 demonstration.

## Functional modules

1. Admin and student login with secure PHP password hashing.
2. Student directory with enrollment, individual accounts and delete functionality.
3. Semester subject management and credit allocation.
4. CIE (out of 40) and ESE (out of 60) mark entry / updates.
5. Automatic letter grades, grade points and credit-weighted SGPA.
6. Searchable student directory, printable results and CSV export.
7. Responsive interface and subject performance chart.

## Demo credentials

| Role | Username | Default password |
|---|---|---|
| Admin | `admin@demo.edu` | `Demo@1234` (unless `ADMIN_PASSWORD` set) |
| Student | `IU260001` | `Student@1234` (unless `DEMO_STUDENT_PASSWORD` set) |

**All seeded people and scores are fictional demonstration data.** Never use default demo passwords with real student records. Admin credentials are seeded at first startup; changing ADMIN_PASSWORD later does not automatically reset an existing admin user in a persistent database.

## Run locally with Docker

```bash
docker build -t iu-resulthub .
docker run --rm -p 10000:10000 \
  -e DB_PASSWORD=localOnly_ChangeMe_123 \
  -e ADMIN_PASSWORD=Demo@1234 \
  -e DEMO_STUDENT_PASSWORD=Student@1234 \
  iu-resulthub
```

Open http://localhost:10000. The Docker container runs PHP/Apache and a MySQL-compatible MariaDB server for easy demonstrations.

## Deploy to Render

1. Connect your GitHub repository and create a **Web Service** with runtime **Docker**, Dockerfile in this folder, and free plan.
2. Set `DB_PASSWORD` to a unique, SQL-quote-safe random password, and set `ADMIN_PASSWORD` and `DEMO_STUDENT_PASSWORD` securely.
3. Set `PORT=10000`, if not already provided by Render.
4. On the deployed demo, open the public URL and log in with the configured username/password.

**Important:** Render free services have an **ephemeral filesystem**. The built-in demo MySQL server will lose added students and marks when a free instance sleeps, restarts, or redeploys. This deployment is for a faculty demo, not durable storage. **For real permanent MySQL storage**, use a managed external MySQL database and set `EXTERNAL_MYSQL_HOST`, `DB_NAME`, `DB_USER`, `DB_PASSWORD`, and `DB_PORT`. The external database must have those credentials and allow Render's outbound connections. Set `SEED_DEMO=0` if you do not want fictional student records; the app still creates its tables and admin account automatically.

## Evaluation and SGPA

`Total = CIE (0–40) + ESE (0–60)`.

| Total | Grade | Point |
|---|---|---|
| 90–100 | O | 10 |
| 80–89 | A+ | 9 |
| 70–79 | A | 8 |
| 60–69 | B+ | 7 |
| 50–59 | B | 6 |
| 40–49 | C | 5 |
| Below 40 | F | 0 |

`SGPA = Σ(credits × grade point) / Σ(credits of assessed subjects)`. This is an editable **project demonstration grading model**, not an assertion of Indus University's official university regulations.

## Security and limitations

- Prepared PDO MySQL statements, HTML escaping, password hashing, session auth, CSRF tokens, role checks.
- Session data is held in ephemeral PHP session files on the demo server.
- Sample credentials/marks are demonstrative only. Change passwords for any actual use.
- This is an academic mini-project and not a university-authorized grading portal.
