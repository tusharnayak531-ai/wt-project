<?php
declare(strict_types=1);

ini_set('display_errors', '0');
error_reporting(E_ALL);
$secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
session_name('IU_RESULTS_SESSION');
session_set_cookie_params(['lifetime'=>0,'path'=>'/','secure'=>$secure,'httponly'=>true,'samesite'=>'Lax']);
session_start();
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: strict-origin-when-cross-origin');

function envv(string $key, string $fallback=''): string { $value = getenv($key); return $value === false ? $fallback : $value; }
function h($value): string { return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function go(string $path='?page=dashboard'): never { header('Location: '.$path); exit; }
function flash(string $message, string $type='success'): void { $_SESSION['flash']=['message'=>$message,'type'=>$type]; }
function csrf(): string { if (!isset($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(24)); return $_SESSION['csrf']; }
function verify_csrf(): void { if (!hash_equals(csrf(), (string)($_POST['csrf'] ?? ''))) { http_response_code(419); exit('Invalid form token. Reload and try again.'); } }
function signed_in(): bool { return isset($_SESSION['user']); }
function is_admin(): bool { return signed_in() && $_SESSION['user']['role'] === 'admin'; }
function grade(float $total): array {
    if ($total>=90) return ['O',10,'Outstanding'];
    if ($total>=80) return ['A+',9,'Excellent'];
    if ($total>=70) return ['A',8,'Very good'];
    if ($total>=60) return ['B+',7,'Good'];
    if ($total>=50) return ['B',6,'Above average'];
    if ($total>=40) return ['C',5,'Pass'];
    return ['F',0,'Fail'];
}

try {
    $dbHost=envv('DB_HOST','127.0.0.1');
    $dbPort=envv('DB_PORT','3306');
    $dbName=envv('DB_NAME','iu_result_portal');
    $pdo=new PDO("mysql:host={$dbHost};port={$dbPort};dbname={$dbName};charset=utf8mb4", envv('DB_USER','resultapp'), envv('DB_PASSWORD',''), [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false]);
    $pdo->exec("CREATE TABLE IF NOT EXISTS students (id INT AUTO_INCREMENT PRIMARY KEY, enrollment VARCHAR(32) NOT NULL UNIQUE, name VARCHAR(120) NOT NULL, email VARCHAR(190) NOT NULL, course VARCHAR(80) NOT NULL DEFAULT 'B.Tech CSE', semester TINYINT UNSIGNED NOT NULL DEFAULT 5, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $pdo->exec("CREATE TABLE IF NOT EXISTS subjects (id INT AUTO_INCREMENT PRIMARY KEY, code VARCHAR(20) NOT NULL UNIQUE, name VARCHAR(100) NOT NULL, semester TINYINT UNSIGNED NOT NULL DEFAULT 5, credits TINYINT UNSIGNED NOT NULL DEFAULT 4) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $pdo->exec("CREATE TABLE IF NOT EXISTS accounts (id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(100) NOT NULL UNIQUE, password_hash VARCHAR(255) NOT NULL, role ENUM('admin','student') NOT NULL DEFAULT 'student', student_id INT NULL UNIQUE, FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $pdo->exec("CREATE TABLE IF NOT EXISTS marks (id INT AUTO_INCREMENT PRIMARY KEY, student_id INT NOT NULL, subject_id INT NOT NULL, cie DECIMAL(5,2) NOT NULL, ese DECIMAL(5,2) NOT NULL, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, UNIQUE KEY one_result(student_id,subject_id), FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE CASCADE, FOREIGN KEY(subject_id) REFERENCES subjects(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    if ((int)$pdo->query('SELECT COUNT(*) FROM subjects')->fetchColumn()===0) {
        $subjectSeed=[['CN','Computer Networks',4],['DAA','Design & Analysis of Algorithms',4],['PSC','Python Scientific Computing',4],['EEWM','Energy & Environmental Management',3],['AMP','Advanced Microprocessors',3],['WT','Web Technology',3]];
        $s=$pdo->prepare('INSERT INTO subjects(code,name,credits,semester) VALUES(?,?,?,5)'); foreach($subjectSeed as $sub) $s->execute($sub);
    }
    if ((int)$pdo->query('SELECT COUNT(*) FROM accounts WHERE role="admin"')->fetchColumn()===0) {
        $p=envv('ADMIN_PASSWORD','Demo@1234');
        $pdo->prepare("INSERT INTO accounts(username,password_hash,role) VALUES(?,?,'admin')")->execute([envv('ADMIN_USERNAME','admin@demo.edu'),password_hash($p,PASSWORD_DEFAULT)]);
    }
    if (envv('SEED_DEMO','1')==='1' && (int)$pdo->query('SELECT COUNT(*) FROM students')->fetchColumn()===0) {
        $seed=[['IU260001','Aarav Shah','aarav@example.edu'],['IU260002','Diya Patel','diya@example.edu'],['IU260003','Rohan Mehta','rohan@example.edu'],['IU260004','Mira Desai','mira@example.edu']];
        $ins=$pdo->prepare("INSERT INTO students(enrollment,name,email,course,semester) VALUES(?,?,?,'B.Tech CSE',5)");
        $account=$pdo->prepare("INSERT INTO accounts(username,password_hash,role,student_id) VALUES(?,?,'student',?)");
        $passHash=password_hash(envv('DEMO_STUDENT_PASSWORD','Student@1234'),PASSWORD_DEFAULT);
        foreach($seed as $student) { $ins->execute($student); $account->execute([$student[0],$passHash,(int)$pdo->lastInsertId()]); }
        $studentIds=$pdo->query('SELECT id FROM students ORDER BY id')->fetchAll(PDO::FETCH_COLUMN);
        $subjectIds=$pdo->query('SELECT id FROM subjects WHERE semester=5 ORDER BY id')->fetchAll(PDO::FETCH_COLUMN);
        $insMark=$pdo->prepare('INSERT INTO marks(student_id,subject_id,cie,ese) VALUES(?,?,?,?)');
        foreach($studentIds as $i=>$sid) foreach($subjectIds as $j=>$subid) { $cie=29+(($i*3+$j*2)%11); $ese=39+(($i*7+$j*4)%20); $insMark->execute([$sid,$subid,$cie,$ese]); }
    }
} catch (Throwable $e) {
    http_response_code(503);
    error_log('Student Result database issue: '.$e->getMessage());
    ?><!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Database unavailable</title><style>body{background:#0b1020;color:#edf0ff;font:16px system-ui;display:grid;place-items:center;min-height:100vh;padding:24px}article{max-width:570px;border:1px solid #2b3655;padding:40px;border-radius:18px;background:#151d32}p{color:#aab8d5;line-height:1.6}</style><article><h1>Database connection unavailable</h1><p>The PHP application is running, but it cannot connect to MySQL. Check the database environment variables or the MySQL service, then refresh.</p><p>For external MySQL, configure DB_HOST, DB_PORT, DB_NAME, DB_USER and DB_PASSWORD in Render.</p></article></html><?php exit;
}

$page=(string)($_GET['page'] ?? (signed_in()?'dashboard':'login'));
$allowed=['login','dashboard','students','subjects','marks','results']; if(!in_array($page,$allowed,true))$page='dashboard';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    verify_csrf();
    $action=(string)($_POST['action']??'');
    try {
        if($action==='login') {
            $username=trim((string)($_POST['username']??''));
            $password=(string)($_POST['password']??'');
            $q=$pdo->prepare('SELECT id,username,password_hash,role,student_id FROM accounts WHERE username=? LIMIT 1');$q->execute([$username]);$u=$q->fetch();
            if(!$u || !password_verify($password,$u['password_hash'])) { flash('Incorrect username or password.','error');go('?page=login'); }
            session_regenerate_id(true); $_SESSION['user']=['id'=>(int)$u['id'],'username'=>$u['username'],'role'=>$u['role'],'student_id'=>$u['student_id']?(int)$u['student_id']:null]; go('?page=dashboard');
        }
        if($action==='logout') { $_SESSION=[];session_regenerate_id(true);flash('You have signed out.');go('?page=login'); }
        if(!is_admin()) { http_response_code(403);exit('Admin permission required'); }
        if($action==='student_save') {
            $name=trim((string)($_POST['name']??''));$enrollment=strtoupper(trim((string)($_POST['enrollment']??'')));$email=trim((string)($_POST['email']??''));
            $course=trim((string)($_POST['course']??'B.Tech CSE'));$semester=(int)($_POST['semester']??5);$pw=(string)($_POST['password']??'');
            if(strlen($name)<2 || !preg_match('/^[A-Z0-9_-]{4,32}$/',$enrollment) || !filter_var($email,FILTER_VALIDATE_EMAIL) || $semester<1 || $semester>8 || strlen($pw)<8) throw new RuntimeException('Enter valid details and a password of at least 8 characters.');
            $pdo->beginTransaction();
            $pdo->prepare('INSERT INTO students(enrollment,name,email,course,semester) VALUES(?,?,?,?,?)')->execute([$enrollment,$name,$email,$course,$semester]);$sid=(int)$pdo->lastInsertId();
            $pdo->prepare("INSERT INTO accounts(username,password_hash,role,student_id) VALUES(?,?,'student',?)")->execute([$enrollment,password_hash($pw,PASSWORD_DEFAULT),$sid]);$pdo->commit();flash('Student account created successfully.');go('?page=students');
        }
        if($action==='student_delete') { $id=(int)($_POST['id']??0);$pdo->prepare('DELETE FROM students WHERE id=?')->execute([$id]);flash('Student and their results deleted.');go('?page=students'); }
        if($action==='subject_save') {
            $code=strtoupper(trim((string)($_POST['code']??'')));$name=trim((string)($_POST['name']??''));$credits=(int)($_POST['credits']??4);$semester=(int)($_POST['semester']??5);
            if(!preg_match('/^[A-Z0-9-]{2,20}$/',$code)||strlen($name)<3||$credits<1||$credits>8||$semester<1||$semester>8)throw new RuntimeException('Please enter valid subject details.');
            $pdo->prepare('INSERT INTO subjects(code,name,credits,semester) VALUES(?,?,?,?)')->execute([$code,$name,$credits,$semester]);flash('Subject added successfully.');go('?page=subjects');
        }
        if($action==='mark_save') {
            $sid=(int)($_POST['student_id']??0);$subid=(int)($_POST['subject_id']??0);
            $cie=filter_var($_POST['cie']??null,FILTER_VALIDATE_FLOAT);$ese=filter_var($_POST['ese']??null,FILTER_VALIDATE_FLOAT);
            if($sid<1||$subid<1||$cie===false||$ese===false||$cie<0||$cie>40||$ese<0||$ese>60) throw new RuntimeException('CIE must be 0–40 and ESE must be 0–60.');
            $q=$pdo->prepare('SELECT 1 FROM students s JOIN subjects b ON s.semester=b.semester WHERE s.id=? AND b.id=?');$q->execute([$sid,$subid]);if(!$q->fetchColumn())throw new RuntimeException('Subject must match student semester.');
            $pdo->prepare('INSERT INTO marks(student_id,subject_id,cie,ese) VALUES(?,?,?,?) ON DUPLICATE KEY UPDATE cie=VALUES(cie),ese=VALUES(ese)')->execute([$sid,$subid,$cie,$ese]);flash('Marks saved and grade calculated.');go('?page=marks&student_id='.$sid);
        }
        throw new RuntimeException('Unknown action.');
    } catch(Throwable $e) {
        if($pdo->inTransaction())$pdo->rollBack();
        flash($e instanceof PDOException && $e->getCode()==='23000'?'That enrollment, email, or subject code already exists.':$e->getMessage(),'error');
        go('?page='.(in_array($page,['login','students','subjects','marks'],true)?$page:'dashboard'));
    }
}
if(!signed_in() && $page!=='login')go('?page=login');
if(signed_in() && $page==='login')go('?page=dashboard');
if(!is_admin() && in_array($page,['students','subjects','marks','dashboard'],true))go('?page=results');

$studentId=is_admin()?(int)($_GET['student_id']??$_GET['id']??0):(int)($_SESSION['user']['student_id']??0);
$students=$pdo->query('SELECT * FROM students ORDER BY id DESC')->fetchAll();
$subjects=$pdo->query('SELECT * FROM subjects ORDER BY semester,code')->fetchAll();
$counts=['students'=>count($students),'subjects'=>count($subjects),'results'=>(int)$pdo->query('SELECT COUNT(*) FROM marks')->fetchColumn()];
$allMarks=$pdo->query('SELECT m.*,s.name AS student_name,s.enrollment,b.code,b.name AS subject_name,b.credits,b.semester FROM marks m JOIN students s ON s.id=m.student_id JOIN subjects b ON b.id=m.subject_id ORDER BY m.updated_at DESC')->fetchAll();
$totalSum=0;foreach($allMarks as $r)$totalSum+=(float)$r['cie']+(float)$r['ese'];$average=$counts['results']?round($totalSum/$counts['results'],1):0;
$selectedStudent=null;$resultRows=[];$sgpa=null;$failed=false;$earned=0;$possible=0;
if($studentId) {
    $q=$pdo->prepare('SELECT * FROM students WHERE id=?');$q->execute([$studentId]);$selectedStudent=$q->fetch()?:null;
    if($selectedStudent){
        $q=$pdo->prepare('SELECT b.*,m.cie,m.ese,m.updated_at FROM subjects b LEFT JOIN marks m ON m.subject_id=b.id AND m.student_id=? WHERE b.semester=? ORDER BY b.code');$q->execute([$studentId,$selectedStudent['semester']]);$resultRows=$q->fetchAll();
        foreach($resultRows as $r)if($r['cie']!==null){$g=grade((float)$r['cie']+(float)$r['ese']);$earned+=(int)$r['credits']*$g[1];$possible+=(int)$r['credits'];if($g[1]===0)$failed=true;}
        $sgpa=$possible?number_format($earned/$possible,2):null;
    }
}
if($page==='results' && ($_GET['export']??'')==='csv' && $selectedStudent){
    header('Content-Type: text/csv; charset=UTF-8');header('Content-Disposition: attachment; filename="result-'.preg_replace('/[^A-Za-z0-9_-]/','',$selectedStudent['enrollment']).'.csv"');
    $out=fopen('php://output','w');fputcsv($out,['Enrollment',$selectedStudent['enrollment']]);fputcsv($out,['Name',$selectedStudent['name']]);fputcsv($out,['Subject','Credits','CIE / 40','ESE / 60','Total / 100','Grade','Grade Point']);
    foreach($resultRows as $r){$t=$r['cie']===null?null:(float)$r['cie']+(float)$r['ese'];$g=$t===null?['—','—']:grade($t);fputcsv($out,[$r['code'].' - '.$r['name'],$r['credits'],$r['cie']??'',$r['ese']??'',$t??'',$g[0],$g[1]]);}fputcsv($out,['SGPA',$sgpa??'N/A']);exit;
}
$flash=$_SESSION['flash']??null;unset($_SESSION['flash']);
?><!doctype html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#101526"><title><?= h(ucfirst($page)) ?> · IU ResultHub</title><link rel="stylesheet" href="assets/style.css"><script defer src="assets/app.js"></script></head>
<body class="<?= $page==='login'?'auth-body':'' ?>">
<?php if($page==='login'): ?>
<div class="auth-layout"><div class="auth-aside"><div class="brand auth-brand"><span class="brand-mark">I<span>U</span></span><span>RESULT<span class="light">HUB</span><small>ACADEMIC MANAGEMENT</small></span></div><div class="auth-copy"><span class="eyebrow">INDUS UNIVERSITY · WT MINI PROJECT</span><h1>Academic results,<br><em>beautifully organized.</em></h1><p>One secure workspace to manage student records, enter marks, calculate grades and publish semester results.</p><div class="feature-chips"><span>✦ Live grade calculation</span><span>✦ SGPA reports</span><span>✦ PHP + MySQL</span></div></div><div class="auth-aside-footer">WEB TECHNOLOGY PROJECT <span>2026 • SEMESTER V</span></div></div><div class="auth-main"><form class="auth-card" method="post"><input type="hidden" name="csrf" value="<?= h(csrf()) ?>"><input type="hidden" name="action" value="login"><div class="login-symbol">↗</div><span class="eyebrow">WELCOME BACK</span><h2>Sign in to ResultHub</h2><p>Enter your credentials to continue to your dashboard.</p><?php if($flash):?><div class="alert <?=h($flash['type'])?>"><?=h($flash['message'])?></div><?php endif;?><label>Username or enrollment number<input name="username" type="text" autocomplete="username" required placeholder="admin@demo.edu"></label><label>Password<input name="password" type="password" autocomplete="current-password" required placeholder="Enter your password"></label><button class="btn primary full" type="submit">Sign in <span>→</span></button><div class="demo-logins"><strong>Demo accounts</strong><div><span>Admin</span><code>admin@demo.edu</code></div><div><span>Student</span><code>IU260001</code></div><small>Passwords are provided in the project README for local demo setups. Deployed credentials may be configured separately.</small></div></form></div></div>
<?php else: ?>
<div class="app-shell"><aside class="sidebar" id="sidebar"><div class="brand"><span class="brand-mark">I<span>U</span></span><span>RESULT<span class="light">HUB</span><small>ACADEMIC MANAGEMENT</small></span></div><p class="nav-label">WORKSPACE</p><nav class="navigation"><a href="?page=dashboard" class="<?= $page==='dashboard'?'active':'' ?>"><span class="nav-icon">▦</span> Overview</a><?php if(is_admin()): ?><a href="?page=students" class="<?= $page==='students'?'active':'' ?>"><span class="nav-icon">♙</span> Students</a><a href="?page=subjects" class="<?= $page==='subjects'?'active':'' ?>"><span class="nav-icon">▤</span> Subjects</a><a href="?page=marks" class="<?= $page==='marks'?'active':'' ?>"><span class="nav-icon">✎</span> Enter Marks</a><?php endif;?><a href="?page=results" class="<?= $page==='results'?'active':'' ?>"><span class="nav-icon">▧</span> Result Reports</a></nav><div class="sidebar-bottom"><div class="workspace-callout"><span class="callout-icon">✧</span><b>Made for academic success.</b><small>WT Mini Project · PHP & MySQL</small></div><span class="sidebar-foot">IU ResultHub <span>v1.0.0</span></span></div></aside>
<div class="main-area"><header class="topbar"><div class="topbar-left"><button id="menuToggle" class="menu-toggle" aria-label="Toggle navigation">☰</button><span class="breadcrumb">Workspace <b>/</b> <?= h(ucwords(str_replace('_',' ',$page))) ?></span></div><div class="topbar-right"><span class="status-dot"></span><span class="live-status">SYSTEM ONLINE</span><span class="avatar"><?= h(strtoupper(substr($_SESSION['user']['username'],0,1))) ?></span><span class="user-meta"><strong><?=is_admin()?'Administrator':'Student Portal'?></strong><small><?= h($_SESSION['user']['username']) ?></small></span><form method="post"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="logout"><button class="signout" title="Log out">⎋</button></form></div></header><main class="content">
<?php if($flash):?><div class="alert <?=h($flash['type'])?>"><?=h($flash['message'])?></div><?php endif;?>
<?php if($page==='dashboard'): ?>
<div class="page-heading"><div><span class="eyebrow">ACADEMIC OVERVIEW / 2026–27</span><h1><?=is_admin()?'Academic Command Center':'My Academic Dashboard'?></h1><p><?=is_admin()?'Monitor student performance and manage semester assessments.':'Explore your subjects, grades, and academic progress.'?></p></div><a class="btn primary" href="?page=<?=is_admin()?'marks':'results'?>"><?=is_admin()?'＋ Add marks':'View my result'?> <span>↗</span></a></div>
<div class="hero"><div><span class="hero-tag">INDUS UNIVERSITY <span>•</span> SEMESTER 05</span><h2>Every result tells<br>a <em>story of progress.</em></h2><p>Centralized academic data. Clearer insights. Better outcomes.</p><a href="?page=results">Explore results <span>↗</span></a></div><div class="hero-art"><div class="orbit large"></div><div class="orbit small"></div><div class="hero-score"><small>ACADEMIC PERFORMANCE</small><strong><?=h(number_format((float)$average,1))?><span>/100</span></strong><div class="hero-score-bar"><span style="width:<?=h((string)$average)?>%"></span></div><small>Overall average score</small></div></div></div>
<div class="stat-grid"><article class="stat-card"><div class="stat-head"><span>TOTAL STUDENTS</span><span class="stat-icon lavender">♙</span></div><strong><?=h((string)$counts['students'])?></strong><small>Registered student profiles</small></article><article class="stat-card"><div class="stat-head"><span>ACTIVE SUBJECTS</span><span class="stat-icon cyan">▤</span></div><strong><?=h((string)$counts['subjects'])?></strong><small>Across academic semesters</small></article><article class="stat-card"><div class="stat-head"><span>MARK ENTRIES</span><span class="stat-icon peach">✎</span></div><strong><?=h((string)$counts['results'])?></strong><small>Published assessments</small></article><article class="stat-card"><div class="stat-head"><span>AVERAGE RESULT</span><span class="stat-icon green">↗</span></div><strong><?=h(number_format((float)$average,1))?><span class="stat-unit">%</span></strong><small>Based on available assessments</small></article></div>
<div class="two-cols"><section class="panel"><div class="panel-head"><div><span class="eyebrow">LEARNING ANALYTICS</span><h3>Subject Performance</h3></div><span class="panel-caption">Average / 100</span></div><div class="subject-bars"><?php foreach($subjects as $sub): $vals=array_filter($allMarks,fn($m)=>(int)$m['subject_id']===(int)$sub['id']);$avgSub=count($vals)?round(array_sum(array_map(fn($m)=>(float)$m['cie']+(float)$m['ese'],$vals))/count($vals)):0;?><div class="bar-row"><span><?=h($sub['code'])?></span><div class="bar-track"><span style="width:<?=h((string)$avgSub)?>%"></span></div><strong><?=h((string)$avgSub)?>%</strong></div><?php endforeach;?></div></section><section class="panel"><div class="panel-head"><div><span class="eyebrow">QUICK ACCESS</span><h3>Management Modules</h3></div></div><div class="quick-links"><?php if(is_admin()):?><a href="?page=students"><span class="quick-icon lavender">♙</span><span><strong>Manage students</strong><small>Enroll or remove students</small></span><b>↗</b></a><a href="?page=marks"><span class="quick-icon peach">✎</span><span><strong>Update marks</strong><small>Enter CIE & ESE scores</small></span><b>↗</b></a><?php endif;?><a href="?page=results"><span class="quick-icon cyan">▧</span><span><strong>Result reports</strong><small>SGPA, grades and downloads</small></span><b>↗</b></a></div></section></div>
<?php elseif($page==='students'): ?>
<div class="page-heading"><div><span class="eyebrow">STUDENT MANAGEMENT</span><h1>Student Directory</h1><p>Manage enrolled students and individual login credentials.</p></div><button class="btn primary" data-open="studentModal">＋ Add student</button></div>
<section class="panel"><div class="panel-head"><h3>All Students <span class="count-pill"><?=count($students)?></span></h3><input class="search" data-search="studentTable" placeholder="⌕  Search students..." aria-label="Search students"></div><div class="table-wrap"><table id="studentTable"><thead><tr><th>STUDENT</th><th>ENROLLMENT</th><th>COURSE</th><th>SEM</th><th>RESULT</th><th>ACTION</th></tr></thead><tbody><?php foreach($students as $s):?><tr><td><div class="student-cell"><span class="student-initial"><?=h(strtoupper(substr($s['name'],0,1)))?></span><span><strong><?=h($s['name'])?></strong><small><?=h($s['email'])?></small></span></div></td><td><code><?=h($s['enrollment'])?></code></td><td><?=h($s['course'])?></td><td><span class="tag muted">SEM <?=h($s['semester'])?></span></td><td><a class="table-link" href="?page=results&id=<?=$s['id']?>">View report ↗</a></td><td><form method="post" onsubmit="return confirm('Delete this student and all their marks?')"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="student_delete"><input type="hidden" name="id" value="<?=$s['id']?>"><button class="danger-link">Delete</button></form></td></tr><?php endforeach;?></tbody></table></div></section>
<div class="modal-backdrop" id="studentModal" hidden><form method="post" class="modal"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="student_save"><div class="modal-head"><div><span class="eyebrow">NEW ENROLLMENT</span><h3>Add a student</h3></div><button type="button" data-close>×</button></div><div class="form-grid"><label>Full name<input name="name" required maxlength="120" placeholder="e.g. Priya Shah"></label><label>Enrollment number<input name="enrollment" required maxlength="32" placeholder="e.g. IU260005"></label><label>Email address<input type="email" name="email" required placeholder="student@example.edu"></label><label>Course<input name="course" value="B.Tech CSE" required maxlength="80"></label><label>Semester<input type="number" name="semester" min="1" max="8" value="5" required></label><label>Student login password<input type="password" name="password" minlength="8" required placeholder="Minimum 8 characters"></label></div><div class="modal-actions"><button class="btn secondary" type="button" data-close>Cancel</button><button class="btn primary">Create student</button></div></form></div>
<?php elseif($page==='subjects'): ?>
<div class="page-heading"><div><span class="eyebrow">CURRICULUM MANAGEMENT</span><h1>Course Subjects</h1><p>Define semester-wise subjects and credits for SGPA calculations.</p></div><button class="btn primary" data-open="subjectModal">＋ Add subject</button></div><section class="panel"><div class="panel-head"><h3>Subjects <span class="count-pill"><?=count($subjects)?></span></h3></div><div class="table-wrap"><table><thead><tr><th>CODE</th><th>SUBJECT NAME</th><th>SEMESTER</th><th>CREDITS</th><th>EVALUATION</th></tr></thead><tbody><?php foreach($subjects as $sub):?><tr><td><span class="tag violet"><?=h($sub['code'])?></span></td><td><strong><?=h($sub['name'])?></strong></td><td>Semester <?=h($sub['semester'])?></td><td><?=h($sub['credits'])?> credits</td><td><span class="tag muted">CIE 40 + ESE 60</span></td></tr><?php endforeach;?></tbody></table></div></section>
<div class="modal-backdrop" id="subjectModal" hidden><form method="post" class="modal"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="subject_save"><div class="modal-head"><div><span class="eyebrow">CURRICULUM</span><h3>Add a subject</h3></div><button type="button" data-close>×</button></div><div class="form-grid"><label>Subject code<input name="code" maxlength="20" required placeholder="e.g. DBMS"></label><label>Subject name<input name="name" maxlength="100" required placeholder="e.g. Database Systems"></label><label>Semester<input type="number" min="1" max="8" name="semester" value="5" required></label><label>Credits<input type="number" min="1" max="8" name="credits" value="4" required></label></div><div class="modal-actions"><button class="btn secondary" type="button" data-close>Cancel</button><button class="btn primary">Save subject</button></div></form></div>
<?php elseif($page==='marks'): ?>
<div class="page-heading"><div><span class="eyebrow">ASSESSMENT MANAGEMENT</span><h1>Enter Student Marks</h1><p>Save CIE and ESE assessments; grades update automatically.</p></div><span class="tag violet">CIE 40 · ESE 60</span></div>
<section class="panel mark-entry"><div class="panel-head"><h3>Select a student</h3></div><form method="get" class="filter-form"><input type="hidden" name="page" value="marks"><select name="student_id" required><option value="">Choose enrolled student...</option><?php foreach($students as $s):?><option value="<?=$s['id']?>" <?=$studentId===(int)$s['id']?'selected':''?>><?=h($s['enrollment'].' · '.$s['name'])?></option><?php endforeach;?></select><button class="btn primary">Load subjects ↗</button></form></section>
<?php if($selectedStudent):?><section class="panel"><div class="panel-head"><div><span class="eyebrow"><?=h($selectedStudent['enrollment'])?></span><h3>Marksheet · <?=h($selectedStudent['name'])?></h3></div><a class="btn secondary small" href="?page=results&id=<?=$selectedStudent['id']?>">View report ↗</a></div><div class="table-wrap"><table><thead><tr><th>SUBJECT</th><th>CREDITS</th><th>CIE / 40</th><th>ESE / 60</th><th>TOTAL / 100</th><th>ACTION</th></tr></thead><tbody><?php foreach($resultRows as $r): $t=$r['cie']===null?null:(float)$r['cie']+(float)$r['ese']; ?><tr><td><form id="mark-<?=$r['id']?>" method="post"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="mark_save"><input type="hidden" name="student_id" value="<?=$selectedStudent['id']?>"><input type="hidden" name="subject_id" value="<?=$r['id']?>"></form><strong><?=h($r['code'])?></strong><small class="table-subtitle"><?=h($r['name'])?></small></td><td><?=h($r['credits'])?></td><td><input form="mark-<?=$r['id']?>" class="mark-input" type="number" step="0.01" min="0" max="40" required name="cie" value="<?=h($r['cie']??'')?>" placeholder="0–40"></td><td><input form="mark-<?=$r['id']?>" class="mark-input" type="number" step="0.01" min="0" max="60" required name="ese" value="<?=h($r['ese']??'')?>" placeholder="0–60"></td><td><strong><?= $t===null?'—':h(number_format($t,1)) ?></strong></td><td><button form="mark-<?=$r['id']?>" class="btn small secondary">Save marks</button></td></tr><?php endforeach;?></tbody></table></div></section><?php endif;?>
<?php elseif($page==='results'): ?>
<div class="page-heading"><div><span class="eyebrow">PERFORMANCE & REPORTS</span><h1>Semester Results</h1><p>Generate detailed marksheets with weighted SGPA and grades.</p></div><?php if($selectedStudent):?><div class="heading-actions"><button class="btn secondary" onclick="window.print()">⎙ Print result</button><a class="btn primary" href="?page=results&id=<?=$selectedStudent['id']?>&export=csv">↓ Export CSV</a></div><?php endif;?></div>
<?php if(is_admin()):?><section class="panel mark-entry no-print"><div class="panel-head"><h3>Find student result</h3></div><form class="filter-form" method="get"><input type="hidden" name="page" value="results"><select name="id"><option value="">Select a student...</option><?php foreach($students as $s):?><option value="<?=$s['id']?>" <?=$studentId===(int)$s['id']?'selected':''?>><?=h($s['enrollment'].' · '.$s['name'])?></option><?php endforeach;?></select><button class="btn primary">Generate report ↗</button></form></section><?php endif;?>
<?php if($selectedStudent): ?><section class="panel result-header"><div class="result-identity"><div class="student-initial xl"><?=h(strtoupper(substr($selectedStudent['name'],0,1)))?></div><div><span class="eyebrow">OFFICIAL SEMESTER REPORT</span><h2><?=h($selectedStudent['name'])?></h2><p><?=h($selectedStudent['enrollment'])?> · <?=h($selectedStudent['course'])?> · Semester <?=h($selectedStudent['semester'])?></p></div></div><div class="sgpa-tile"><span>SEMESTER SGPA</span><strong><?=$sgpa===null?'—':h($sgpa)?><small> / 10.00</small></strong><span class="tag <?=$failed?'danger':'success'?>"><?=$sgpa===null?'Not assessed':($failed?'Needs improvement':'Results available')?></span></div></section>
<section class="panel"><div class="panel-head"><div><span class="eyebrow">GRADE REPORT</span><h3>Subject-wise Marksheet</h3></div><span class="tag muted">CIE / 40 + ESE / 60</span></div><div class="table-wrap"><table><thead><tr><th>CODE</th><th>SUBJECT</th><th>CR</th><th>CIE</th><th>ESE</th><th>TOTAL</th><th>GRADE</th><th>POINT</th></tr></thead><tbody><?php foreach($resultRows as $r):$t=$r['cie']===null?null:(float)$r['cie']+(float)$r['ese'];$g=$t===null?['—','—','Pending']:grade($t);?><tr><td><span class="tag violet"><?=h($r['code'])?></span></td><td><strong><?=h($r['name'])?></strong></td><td><?=h($r['credits'])?></td><td><?=h($r['cie']??'—')?></td><td><?=h($r['ese']??'—')?></td><td><strong><?=$t===null?'—':h(number_format($t,1))?></strong></td><td><span class="tag <?=$g[0]==='F'?'danger':($g[0]==='—'?'muted':'success')?>"><?=h($g[0])?></span></td><td><?=h($g[1])?></td></tr><?php endforeach;?></tbody></table></div><div class="result-foot"><div><b>SGPA formula</b><small>Σ (credit × grade point) ÷ Σ credits of assessed subjects. Failed subjects count as 0 points.</small></div><strong><?=h($sgpa??'N/A')?> / 10.00</strong></div></section>
<?php else:?><section class="panel empty-state"><span class="empty-icon">▧</span><h3>No result selected</h3><p><?=is_admin()?'Select a student above to generate a result report.':'Your student record has not been found.'?></p></section><?php endif;?>
<?php endif; ?>
<footer class="footer"><span>© 2026 IU ResultHub. Built for Web Technology.</span><span>HTML · CSS · JavaScript · PHP · MySQL</span></footer>
</main></div></div>
<?php endif; ?></body></html>
